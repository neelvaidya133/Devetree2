import React from "react";
import Contact from "./Pages/Contact/Contact";

const Test = () => {
  return <Contact />;
};

export default Test;
