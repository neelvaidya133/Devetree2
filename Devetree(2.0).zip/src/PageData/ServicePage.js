import Back from "../Assets/Icons/Group 81.png";
export const PageTwo = {
  Image: Back,
  imgStart: "",
  Heading: "What We Provide?",
  length: "full",
  color1: " linear-gradient(180deg, #FFF500 0%, #2400FF 100%)",
  color2: "linear-gradient(180deg, #2400FF 0%, #FF0000 100%)",

  HorizantalLineColor: "linear-gradient(90deg, #F2F50D 0%, #F2F50D 100%)",
  Text: "Our software engineering services include requirements analysis and design, development, testing, maintenance, and support. We use cutting-edge technology and industry-standard methodologies to ensure that our services are reliable and secure. Moreover, our team members are well-versed in the latest software engineering trends and technologies, allowing us to deliver the most up-to-date solutions.",
};
