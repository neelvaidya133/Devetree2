import ReactIcon from "../../Assets/Carousale/science (1) 2.svg";
import NodeIcon from "../../Assets/Carousale/pngegg 2.svg";

export const CardObj = [
  {
    title: "React",
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
    icon: ReactIcon,
  },
  {
    icon: ReactIcon,

    title: "React Native",
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "Node JS",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "Java Script",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "PHP Laravel",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "Android Development",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "IOS Development",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "ASP.Net",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
  {
    title: "Flutter",
    icon: NodeIcon,
    subtitle:
      "Develop application for app Store and play Store to grow your business.",
  },
];
